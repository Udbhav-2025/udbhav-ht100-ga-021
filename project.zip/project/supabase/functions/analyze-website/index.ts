import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface AnalysisRequest {
  url: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { url }: AnalysisRequest = await req.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        {
          status: 400,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const websiteContent = await fetchWebsiteContent(url);
    const analysis = await analyzeWebsite(url, websiteContent);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { data, error } = await supabase
      .from('website_analyses')
      .insert({
        url,
        analysis_data: analysis.analysis,
        marketing_suggestions: analysis.marketing,
        social_media_content: analysis.socialMedia,
        redesign_suggestions: analysis.redesign,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return new Response(
      JSON.stringify({ success: true, data, analysis }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});

async function fetchWebsiteContent(url: string): Promise<string> {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; MarketingBot/1.0)',
      },
    });
    const html = await response.text();
    return html.substring(0, 5000);
  } catch (error) {
    console.error('Error fetching website:', error);
    return '';
  }
}

async function analyzeWebsite(url: string, content: string) {
  const domain = new URL(url).hostname;
  
  const title = content.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1] || 'Website';
  const description = content.match(/<meta[^>]*name=["']description["'][^>]*content=["']([^"']+)["']/i)?.[1] || '';
  
  const hasImages = /<img/i.test(content);
  const hasVideo = /<video|<iframe.*youtube|<iframe.*vimeo/i.test(content);
  const hasCTA = /buy|shop|get started|sign up|subscribe|download/i.test(content);
  const hasTestimonials = /testimonial|review|customer|client/i.test(content);
  const hasSocial = /facebook|twitter|instagram|linkedin|social/i.test(content);
  
  const colorMatches = content.match(/#[0-9a-f]{3,6}/gi) || [];
  const dominantColors = [...new Set(colorMatches)].slice(0, 5);

  const analysis = {
    title,
    description,
    domain,
    features: {
      hasImages,
      hasVideo,
      hasCTA,
      hasTestimonials,
      hasSocialLinks: hasSocial,
    },
    colors: dominantColors,
    contentLength: content.length,
  };

  const businessType = determineBusinessType(content, title);
  const targetAudience = determineAudience(content, businessType);

  const marketing = {
    businessType,
    targetAudience,
    valueProposition: generateValueProposition(businessType, title),
    slogans: generateSlogans(businessType, title),
    brandVoice: generateBrandVoice(businessType),
    keyMessages: generateKeyMessages(businessType, targetAudience),
  };

  const socialMedia = {
    instagram: generateInstagramPosts(businessType, title),
    facebook: generateFacebookPosts(businessType, title),
    twitter: generateTwitterPosts(businessType, title),
    contentStrategy: generateContentStrategy(businessType),
    hashtagSuggestions: generateHashtags(businessType),
  };

  const redesign = {
    colorScheme: generateColorScheme(businessType),
    typography: generateTypography(businessType),
    layoutSuggestions: generateLayoutSuggestions(businessType, analysis.features),
    ctaSuggestions: generateCTASuggestions(businessType),
    imageSuggestions: generateImageSuggestions(businessType),
    improvements: generateImprovements(analysis.features),
  };

  return { analysis, marketing, socialMedia, redesign };
}

function determineBusinessType(content: string, title: string): string {
  const text = (content + ' ' + title).toLowerCase();
  
  if (/e-commerce|shop|store|buy|product|cart/i.test(text)) return 'E-commerce';
  if (/saas|software|platform|app|service/i.test(text)) return 'SaaS';
  if (/restaurant|food|cafe|menu|dining/i.test(text)) return 'Restaurant';
  if (/fitness|gym|workout|health|wellness/i.test(text)) return 'Fitness & Wellness';
  if (/real estate|property|homes|apartment/i.test(text)) return 'Real Estate';
  if (/consult|agency|service|professional/i.test(text)) return 'Professional Services';
  if (/education|course|learn|training|school/i.test(text)) return 'Education';
  
  return 'General Business';
}

function determineAudience(content: string, businessType: string): string[] {
  const audienceMap: Record<string, string[]> = {
    'E-commerce': ['Online shoppers', 'Value-conscious consumers', 'Trend followers'],
    'SaaS': ['Business professionals', 'Entrepreneurs', 'Tech-savvy users'],
    'Restaurant': ['Food enthusiasts', 'Local community', 'Families'],
    'Fitness & Wellness': ['Health-conscious individuals', 'Fitness enthusiasts', 'Wellness seekers'],
    'Real Estate': ['Home buyers', 'Property investors', 'Renters'],
    'Professional Services': ['Business owners', 'Corporate clients', 'Professionals'],
    'Education': ['Students', 'Professionals seeking growth', 'Lifelong learners'],
    'General Business': ['General consumers', 'Local community', 'Online audience'],
  };
  
  return audienceMap[businessType] || audienceMap['General Business'];
}

function generateValueProposition(businessType: string, title: string): string {
  const propMap: Record<string, string> = {
    'E-commerce': `Discover premium products that transform your lifestyle - ${title} delivers quality and value to your doorstep`,
    'SaaS': `Streamline your workflow and boost productivity with ${title} - the smart solution for modern businesses`,
    'Restaurant': `Experience culinary excellence at ${title} - where every meal is a memorable celebration`,
    'Fitness & Wellness': `Transform your health journey with ${title} - your partner in achieving wellness goals`,
    'Real Estate': `Find your dream space with ${title} - connecting you with exceptional properties`,
    'Professional Services': `Elevate your business with ${title} - expert solutions tailored to your success`,
    'Education': `Unlock your potential with ${title} - empowering learning that drives real results`,
    'General Business': `Experience excellence with ${title} - where quality meets innovation`,
  };
  
  return propMap[businessType] || propMap['General Business'];
}

function generateSlogans(businessType: string, title: string): string[] {
  const sloganSets: Record<string, string[]> = {
    'E-commerce': [
      'Shop Smarter, Live Better',
      'Quality You Can Trust, Prices You\'ll Love',
      'Your Style, Delivered',
      'Where Quality Meets Affordability',
    ],
    'SaaS': [
      'Work Smarter, Not Harder',
      'Powering Your Success',
      'Innovation Made Simple',
      'Your Business, Amplified',
    ],
    'Restaurant': [
      'Taste the Difference',
      'Where Flavor Meets Passion',
      'Culinary Excellence, Every Bite',
      'Creating Memorable Moments',
    ],
    'Fitness & Wellness': [
      'Transform Your Life Today',
      'Strength. Balance. Wellness.',
      'Your Journey to Better',
      'Empowering Healthy Living',
    ],
    'Real Estate': [
      'Your Dream Home Awaits',
      'Where Life Happens',
      'Building Dreams, Creating Homes',
      'Find Your Perfect Space',
    ],
    'Professional Services': [
      'Excellence in Every Detail',
      'Your Success, Our Mission',
      'Expert Solutions, Real Results',
      'Partnership You Can Trust',
    ],
    'Education': [
      'Learn Today, Lead Tomorrow',
      'Knowledge That Transforms',
      'Empowering Your Future',
      'Education That Inspires',
    ],
    'General Business': [
      'Excellence Delivered',
      'Your Trusted Partner',
      'Quality You Deserve',
      'Making Excellence Standard',
    ],
  };
  
  return sloganSets[businessType] || sloganSets['General Business'];
}

function generateBrandVoice(businessType: string): object {
  const voiceMap: Record<string, object> = {
    'E-commerce': { tone: 'Friendly and enthusiastic', style: 'Conversational', personality: 'Approachable and trendy' },
    'SaaS': { tone: 'Professional and confident', style: 'Clear and direct', personality: 'Innovative and reliable' },
    'Restaurant': { tone: 'Warm and inviting', style: 'Descriptive and sensory', personality: 'Passionate and authentic' },
    'Fitness & Wellness': { tone: 'Motivating and supportive', style: 'Energetic', personality: 'Empowering and positive' },
    'Real Estate': { tone: 'Trustworthy and professional', style: 'Informative', personality: 'Sophisticated and helpful' },
    'Professional Services': { tone: 'Authoritative and polished', style: 'Professional', personality: 'Expert and dependable' },
    'Education': { tone: 'Inspiring and encouraging', style: 'Educational', personality: 'Knowledgeable and supportive' },
    'General Business': { tone: 'Professional and friendly', style: 'Balanced', personality: 'Reliable and approachable' },
  };
  
  return voiceMap[businessType] || voiceMap['General Business'];
}

function generateKeyMessages(businessType: string, audience: string[]): string[] {
  return [
    `We understand ${audience[0].toLowerCase()} need reliable solutions`,
    'Quality and excellence are at the heart of everything we do',
    'Your satisfaction is our top priority',
    'Join thousands of happy customers who trust us',
    'Experience the difference that expertise makes',
  ];
}

function generateInstagramPosts(businessType: string, title: string): object[] {
  return [
    {
      caption: `✨ Discover what makes us different! ${title} is here to transform your experience. What are you waiting for? 🚀\n\n#${title.replace(/\s+/g, '')} #Innovation #Quality`,
      imageIdea: 'Hero shot of your product/service in action with vibrant, eye-catching colors',
      postType: 'Promotional',
    },
    {
      caption: `Behind every great experience is a passionate team. Meet the people who make it happen! 💪\n\n#TeamTuesday #BehindTheScenes #OurStory`,
      imageIdea: 'Team photo or behind-the-scenes content showing authentic moments',
      postType: 'Brand Story',
    },
    {
      caption: `Customer love 💙 "This changed everything for me!" - Happy Customer\n\nReady to experience the difference? Link in bio!\n\n#Testimonial #CustomerLove #Results`,
      imageIdea: 'Customer testimonial graphic with quote overlay on branded background',
      postType: 'Social Proof',
    },
    {
      caption: `Pro tip: [Insert valuable tip related to your industry] 🎯\n\nSave this for later and share with someone who needs to see this!\n\n#Tips #Value #Community`,
      imageIdea: 'Educational carousel or infographic with actionable tips',
      postType: 'Educational',
    },
  ];
}

function generateFacebookPosts(businessType: string, title: string): object[] {
  return [
    {
      post: `We're excited to share what makes ${title} special! 🌟\n\nOur commitment to excellence means you get:\n✅ Top-quality service\n✅ Unmatched value\n✅ A team that cares\n\nLearn more and join our community today!`,
      contentType: 'Announcement',
      engagementTip: 'Ask a question at the end to boost comments',
    },
    {
      post: `Success Story Alert! 📣\n\nHear from our customer about how we helped them achieve their goals. Real people, real results.\n\nWant to be our next success story? Get in touch today!`,
      contentType: 'Case Study',
      engagementTip: 'Include a customer video or detailed testimonial',
    },
    {
      post: `Did you know? [Interesting fact related to your industry]\n\nAt ${title}, we're passionate about sharing knowledge and helping you succeed. What else would you like to know? Drop your questions below! 👇`,
      contentType: 'Educational',
      engagementTip: 'Create conversation by asking for their experiences',
    },
  ];
}

function generateTwitterPosts(businessType: string, title: string): object[] {
  return [
    {
      tweet: `🚀 Big things happening at ${title}! We're revolutionizing the way you [solve problem]. Ready to experience the difference?`,
      contentType: 'Announcement',
    },
    {
      tweet: `Quick tip: [Insert 1 valuable tip] 💡\n\nThis simple change can make a huge difference. Try it today!`,
      contentType: 'Value Tweet',
    },
    {
      tweet: `What our customers say: "Life-changing!" 🌟\n\n[Include brief testimonial snippet]\n\nWant to be next? Let's talk!`,
      contentType: 'Social Proof',
    },
    {
      tweet: `Monday motivation: Success isn't just about what you achieve, but who you help along the way. Let's grow together! 💪`,
      contentType: 'Engagement',
    },
  ];
}

function generateContentStrategy(businessType: string): object {
  return {
    postingFrequency: {
      instagram: '5-7 posts per week + daily stories',
      facebook: '3-5 posts per week',
      twitter: '3-5 tweets per day',
    },
    contentMix: {
      promotional: '20%',
      educational: '40%',
      entertaining: '20%',
      userGenerated: '20%',
    },
    bestTimesToPost: {
      instagram: '11am-1pm and 7pm-9pm',
      facebook: '1pm-4pm',
      twitter: '8am-10am and 6pm-9pm',
    },
  };
}

function generateHashtags(businessType: string): object {
  const hashtagSets: Record<string, string[]> = {
    'E-commerce': ['#ShopSmall', '#OnlineShopping', '#Ecommerce', '#ShopNow', '#NewArrivals', '#SaleAlert'],
    'SaaS': ['#SaaS', '#TechSolutions', '#Productivity', '#BusinessTools', '#DigitalTransformation', '#Innovation'],
    'Restaurant': ['#Foodie', '#FoodLover', '#DineLocal', '#FoodExperience', '#ChefLife', '#Delicious'],
    'Fitness & Wellness': ['#FitnessMotivation', '#HealthyLiving', '#WellnessJourney', '#FitnessGoals', '#Workout', '#SelfCare'],
    'Real Estate': ['#RealEstate', '#DreamHome', '#PropertyForSale', '#HouseHunting', '#RealEstateAgent', '#NewHome'],
    'Professional Services': ['#BusinessServices', '#Professional', '#Consulting', '#BusinessGrowth', '#ExpertAdvice', '#B2B'],
    'Education': ['#Education', '#Learning', '#OnlineLearning', '#SkillDevelopment', '#Knowledge', '#GrowthMindset'],
    'General Business': ['#Business', '#Entrepreneur', '#SmallBusiness', '#Success', '#Growth', '#Quality'],
  };
  
  return {
    branded: ['#YourBrandName', '#YourCompanyName'],
    industry: hashtagSets[businessType] || hashtagSets['General Business'],
    trending: ['#MondayMotivation', '#ThrowbackThursday', '#FridayFeeling'],
  };
}

function generateColorScheme(businessType: string): object {
  const colorSchemes: Record<string, object> = {
    'E-commerce': { primary: '#FF6B6B', secondary: '#4ECDC4', accent: '#FFE66D', neutral: '#2C3E50' },
    'SaaS': { primary: '#3498DB', secondary: '#2ECC71', accent: '#F39C12', neutral: '#34495E' },
    'Restaurant': { primary: '#E74C3C', secondary: '#F39C12', accent: '#27AE60', neutral: '#2C2C2C' },
    'Fitness & Wellness': { primary: '#2ECC71', secondary: '#3498DB', accent: '#E67E22', neutral: '#34495E' },
    'Real Estate': { primary: '#2C3E50', secondary: '#C0A062', accent: '#3498DB', neutral: '#7F8C8D' },
    'Professional Services': { primary: '#2C3E50', secondary: '#3498DB', accent: '#95A5A6', neutral: '#34495E' },
    'Education': { primary: '#9B59B6', secondary: '#3498DB', accent: '#F39C12', neutral: '#2C3E50' },
    'General Business': { primary: '#3498DB', secondary: '#2ECC71', accent: '#E74C3C', neutral: '#2C3E50' },
  };
  
  return colorSchemes[businessType] || colorSchemes['General Business'];
}

function generateTypography(businessType: string): object {
  return {
    heading: { font: 'Montserrat, sans-serif', weight: '700', usage: 'Headlines and major sections' },
    subheading: { font: 'Open Sans, sans-serif', weight: '600', usage: 'Subheadings and section titles' },
    body: { font: 'Inter, sans-serif', weight: '400', usage: 'Body text and descriptions' },
  };
}

function generateLayoutSuggestions(businessType: string, features: any): string[] {
  const suggestions = [
    'Implement a bold hero section with compelling headline and clear CTA',
    'Add social proof section with customer testimonials and trust badges',
    'Create a features/benefits grid with icons and concise descriptions',
    'Include a FAQ section to address common concerns',
    'Add a newsletter signup to capture leads',
  ];
  
  if (!features.hasVideo) {
    suggestions.push('Add video content to increase engagement by 80%');
  }
  
  if (!features.hasCTA) {
    suggestions.push('Place clear CTAs above the fold and throughout the page');
  }
  
  return suggestions;
}

function generateCTASuggestions(businessType: string): string[] {
  const ctaSets: Record<string, string[]> = {
    'E-commerce': ['Shop Now', 'View Collection', 'Limited Time Offer', 'Add to Cart', 'Get Yours Today'],
    'SaaS': ['Start Free Trial', 'Get Started', 'Book a Demo', 'See It In Action', 'Try It Free'],
    'Restaurant': ['Reserve a Table', 'Order Online', 'View Menu', 'Book Now', 'Join Us'],
    'Fitness & Wellness': ['Start Your Journey', 'Join Now', 'Get Your Free Pass', 'Transform Today', 'Book a Session'],
    'Real Estate': ['Schedule a Viewing', 'Explore Properties', 'Contact Agent', 'Get Started', 'Find Your Home'],
    'Professional Services': ['Get a Quote', 'Contact Us', 'Schedule Consultation', 'Learn More', 'Partner With Us'],
    'Education': ['Enroll Now', 'Start Learning', 'View Courses', 'Join Today', 'Get Started Free'],
    'General Business': ['Get Started', 'Learn More', 'Contact Us', 'Join Now', 'Discover More'],
  };
  
  return ctaSets[businessType] || ctaSets['General Business'];
}

function generateImageSuggestions(businessType: string): string[] {
  return [
    'High-quality hero images that showcase your product/service',
    'Authentic photos of real customers and team members',
    'Before/after or result-driven imagery',
    'Lifestyle images that connect emotionally with your audience',
    'Professional product photography with clean backgrounds',
    'Infographics to visualize data and processes',
  ];
}

function generateImprovements(features: any): string[] {
  const improvements = [];
  
  if (!features.hasImages || !features.hasVideo) {
    improvements.push('Add more visual content to increase engagement and reduce bounce rate');
  }
  
  if (!features.hasCTA) {
    improvements.push('Add clear calls-to-action throughout the page to guide user journey');
  }
  
  if (!features.hasTestimonials) {
    improvements.push('Include customer testimonials to build trust and credibility');
  }
  
  if (!features.hasSocialLinks) {
    improvements.push('Add social media links to expand your online presence');
  }
  
  improvements.push('Optimize page load speed for better user experience');
  improvements.push('Ensure mobile responsiveness across all devices');
  improvements.push('Implement SEO best practices for better visibility');
  
  return improvements;
}