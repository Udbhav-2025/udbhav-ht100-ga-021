/*
  # Website Analysis Marketing Agent Schema

  1. New Tables
    - `website_analyses`
      - `id` (uuid, primary key) - Unique identifier for each analysis
      - `user_id` (uuid, nullable) - References auth.users for authenticated users
      - `url` (text) - The website URL being analyzed
      - `analysis_data` (jsonb) - Stores the AI analysis results
      - `marketing_suggestions` (jsonb) - Marketing and branding suggestions
      - `social_media_content` (jsonb) - Generated social media post suggestions
      - `redesign_suggestions` (jsonb) - UI/UX redesign recommendations
      - `created_at` (timestamptz) - Timestamp of analysis creation
      - `updated_at` (timestamptz) - Timestamp of last update

  2. Security
    - Enable RLS on `website_analyses` table
    - Add policies for:
      - Public users can create analyses (insert)
      - Users can view their own analyses (select)
      - Users can update their own analyses (update)
      - Users can delete their own analyses (delete)

  3. Notes
    - Analysis data is stored in JSONB format for flexibility
    - Supports both authenticated and anonymous users
    - Each analysis includes comprehensive marketing insights
*/

CREATE TABLE IF NOT EXISTS website_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  analysis_data jsonb DEFAULT '{}'::jsonb,
  marketing_suggestions jsonb DEFAULT '{}'::jsonb,
  social_media_content jsonb DEFAULT '{}'::jsonb,
  redesign_suggestions jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE website_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can create analyses"
  ON website_analyses
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "Users can view own analyses"
  ON website_analyses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Anonymous users can view their analyses"
  ON website_analyses
  FOR SELECT
  TO anon
  USING (user_id IS NULL);

CREATE POLICY "Users can update own analyses"
  ON website_analyses
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own analyses"
  ON website_analyses
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_website_analyses_user_id ON website_analyses(user_id);
CREATE INDEX IF NOT EXISTS idx_website_analyses_created_at ON website_analyses(created_at DESC);