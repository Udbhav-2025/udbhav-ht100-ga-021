export interface WebsiteAnalysis {
  id: string;
  url: string;
  analysis_data: AnalysisData;
  marketing_suggestions: MarketingSuggestions;
  social_media_content: SocialMediaContent;
  redesign_suggestions: RedesignSuggestions;
  created_at: string;
}

export interface AnalysisData {
  title: string;
  description: string;
  domain: string;
  features: {
    hasImages: boolean;
    hasVideo: boolean;
    hasCTA: boolean;
    hasTestimonials: boolean;
    hasSocialLinks: boolean;
  };
  colors: string[];
  contentLength: number;
}

export interface MarketingSuggestions {
  businessType: string;
  targetAudience: string[];
  valueProposition: string;
  slogans: string[];
  brandVoice: {
    tone: string;
    style: string;
    personality: string;
  };
  keyMessages: string[];
}

export interface SocialMediaContent {
  instagram: InstagramPost[];
  facebook: FacebookPost[];
  twitter: TwitterPost[];
  contentStrategy: ContentStrategy;
  hashtagSuggestions: HashtagSuggestions;
}

export interface InstagramPost {
  caption: string;
  imageIdea: string;
  postType: string;
}

export interface FacebookPost {
  post: string;
  contentType: string;
  engagementTip: string;
}

export interface TwitterPost {
  tweet: string;
  contentType: string;
}

export interface ContentStrategy {
  postingFrequency: {
    instagram: string;
    facebook: string;
    twitter: string;
  };
  contentMix: {
    promotional: string;
    educational: string;
    entertaining: string;
    userGenerated: string;
  };
  bestTimesToPost: {
    instagram: string;
    facebook: string;
    twitter: string;
  };
}

export interface HashtagSuggestions {
  branded: string[];
  industry: string[];
  trending: string[];
}

export interface RedesignSuggestions {
  colorScheme: {
    primary: string;
    secondary: string;
    accent: string;
    neutral: string;
  };
  typography: {
    heading: { font: string; weight: string; usage: string };
    subheading: { font: string; weight: string; usage: string };
    body: { font: string; weight: string; usage: string };
  };
  layoutSuggestions: string[];
  ctaSuggestions: string[];
  imageSuggestions: string[];
  improvements: string[];
}
