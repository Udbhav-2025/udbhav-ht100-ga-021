import { Palette, Type, Layout, MousePointerClick, Image, Lightbulb } from 'lucide-react';
import type { RedesignSuggestions as RedesignSuggestionsType } from '../types/analysis';

interface RedesignSuggestionsProps {
  redesign: RedesignSuggestionsType;
}

export default function RedesignSuggestions({ redesign }: RedesignSuggestionsProps) {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-100 rounded-xl">
            <Palette className="h-6 w-6 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Color Scheme</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Object.entries(redesign.colorScheme).map(([name, color]) => (
            <div key={name} className="space-y-2">
              <div
                className="w-full h-24 rounded-xl shadow-md border-2 border-gray-200"
                style={{ backgroundColor: color }}
              ></div>
              <div className="text-center">
                <p className="font-semibold text-gray-900 capitalize">{name}</p>
                <p className="text-sm text-gray-500 font-mono">{color}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-100 rounded-xl">
            <Type className="h-6 w-6 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Typography</h2>
        </div>
        <div className="space-y-6">
          {Object.entries(redesign.typography).map(([type, details]) => (
            <div key={type} className="p-5 bg-gray-50 rounded-xl">
              <h3 className="font-bold text-lg text-gray-900 capitalize mb-3">{type}</h3>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Font:</span>
                  <p className="font-semibold text-gray-900">{details.font}</p>
                </div>
                <div>
                  <span className="text-gray-600">Weight:</span>
                  <p className="font-semibold text-gray-900">{details.weight}</p>
                </div>
                <div>
                  <span className="text-gray-600">Usage:</span>
                  <p className="font-semibold text-gray-900">{details.usage}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-green-100 rounded-xl">
            <Layout className="h-6 w-6 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Layout Suggestions</h2>
        </div>
        <div className="space-y-3">
          {redesign.layoutSuggestions.map((suggestion, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors"
            >
              <span className="flex-shrink-0 w-6 h-6 bg-green-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                {idx + 1}
              </span>
              <p className="text-gray-800">{suggestion}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-orange-100 rounded-xl">
              <MousePointerClick className="h-6 w-6 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Call-to-Action Ideas</h2>
          </div>
          <div className="flex flex-wrap gap-3">
            {redesign.ctaSuggestions.map((cta, idx) => (
              <button
                key={idx}
                className="px-6 py-3 bg-gradient-to-r from-orange-500 to-red-500 text-white font-semibold rounded-lg hover:shadow-lg transition-all transform hover:scale-105"
              >
                {cta}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-pink-100 rounded-xl">
              <Image className="h-6 w-6 text-pink-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Image Guidelines</h2>
          </div>
          <div className="space-y-3">
            {redesign.imageSuggestions.map((suggestion, idx) => (
              <div
                key={idx}
                className="flex items-start gap-2 text-sm text-gray-700"
              >
                <span className="text-pink-500 mt-0.5">•</span>
                <p>{suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl shadow-lg p-8 border border-blue-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-600 rounded-xl">
            <Lightbulb className="h-6 w-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Key Improvements</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {redesign.improvements.map((improvement, idx) => (
            <div
              key={idx}
              className="p-5 bg-white rounded-xl shadow-sm border border-blue-100 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start gap-3">
                <span className="flex-shrink-0 w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center font-bold">
                  {idx + 1}
                </span>
                <p className="text-gray-800 pt-1">{improvement}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
