import { Target, Lightbulb, MessageSquare, TrendingUp } from 'lucide-react';
import type { MarketingSuggestions } from '../types/analysis';

interface MarketingResultsProps {
  marketing: MarketingSuggestions;
}

export default function MarketingResults({ marketing }: MarketingResultsProps) {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-100 rounded-xl">
            <Target className="h-6 w-6 text-blue-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Business Analysis</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold text-gray-700 mb-2">Business Type</h3>
            <p className="text-lg text-gray-900">{marketing.businessType}</p>
          </div>
          <div>
            <h3 className="font-semibold text-gray-700 mb-2">Target Audience</h3>
            <ul className="space-y-1">
              {marketing.targetAudience.map((audience, idx) => (
                <li key={idx} className="text-gray-900 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full"></span>
                  {audience}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl shadow-lg p-8 border border-blue-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-blue-600 rounded-xl">
            <Lightbulb className="h-6 w-6 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Value Proposition</h2>
        </div>
        <p className="text-lg text-gray-800 leading-relaxed">
          {marketing.valueProposition}
        </p>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-emerald-100 rounded-xl">
            <MessageSquare className="h-6 w-6 text-emerald-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Powerful Slogans</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {marketing.slogans.map((slogan, idx) => (
            <div
              key={idx}
              className="p-5 bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl border border-gray-200 hover:shadow-md transition-shadow"
            >
              <p className="text-gray-900 font-medium text-center">
                "{slogan}"
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-purple-100 rounded-xl">
            <TrendingUp className="h-6 w-6 text-purple-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Brand Voice</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="p-5 bg-gray-50 rounded-xl">
            <h3 className="font-semibold text-gray-700 mb-2">Tone</h3>
            <p className="text-gray-900">{marketing.brandVoice.tone}</p>
          </div>
          <div className="p-5 bg-gray-50 rounded-xl">
            <h3 className="font-semibold text-gray-700 mb-2">Style</h3>
            <p className="text-gray-900">{marketing.brandVoice.style}</p>
          </div>
          <div className="p-5 bg-gray-50 rounded-xl">
            <h3 className="font-semibold text-gray-700 mb-2">Personality</h3>
            <p className="text-gray-900">{marketing.brandVoice.personality}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
        <h3 className="font-bold text-xl text-gray-900 mb-4">Key Messages</h3>
        <div className="space-y-3">
          {marketing.keyMessages.map((message, idx) => (
            <div
              key={idx}
              className="flex items-start gap-3 p-4 bg-blue-50 rounded-lg"
            >
              <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                {idx + 1}
              </span>
              <p className="text-gray-800">{message}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
