import { Instagram, Facebook, Twitter, Hash, Calendar, TrendingUp } from 'lucide-react';
import type { SocialMediaContent as SocialMediaContentType } from '../types/analysis';

interface SocialMediaContentProps {
  socialMedia: SocialMediaContentType;
}

export default function SocialMediaContent({ socialMedia }: SocialMediaContentProps) {
  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-pink-500 to-purple-600 rounded-2xl shadow-lg p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <Instagram className="h-8 w-8" />
          <h2 className="text-2xl font-bold">Instagram Content Ideas</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {socialMedia.instagram.map((post, idx) => (
            <div key={idx} className="bg-white/10 backdrop-blur rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold bg-white/20 px-3 py-1 rounded-full">
                  {post.postType}
                </span>
              </div>
              <p className="text-white text-sm leading-relaxed whitespace-pre-line">
                {post.caption}
              </p>
              <div className="pt-3 border-t border-white/20">
                <p className="text-xs text-white/80 italic">
                  Image: {post.imageIdea}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl shadow-lg p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <Facebook className="h-8 w-8" />
          <h2 className="text-2xl font-bold">Facebook Content Ideas</h2>
        </div>
        <div className="space-y-4">
          {socialMedia.facebook.map((post, idx) => (
            <div key={idx} className="bg-white/10 backdrop-blur rounded-xl p-6 space-y-3">
              <span className="inline-block text-sm font-semibold bg-white/20 px-3 py-1 rounded-full">
                {post.contentType}
              </span>
              <p className="text-white leading-relaxed whitespace-pre-line">
                {post.post}
              </p>
              <div className="pt-3 border-t border-white/20">
                <p className="text-xs text-white/80">
                  💡 Tip: {post.engagementTip}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-r from-sky-400 to-blue-500 rounded-2xl shadow-lg p-8 text-white">
        <div className="flex items-center gap-3 mb-6">
          <Twitter className="h-8 w-8" />
          <h2 className="text-2xl font-bold">Twitter/X Content Ideas</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-4">
          {socialMedia.twitter.map((post, idx) => (
            <div key={idx} className="bg-white/10 backdrop-blur rounded-xl p-5 space-y-3">
              <span className="text-sm font-semibold bg-white/20 px-3 py-1 rounded-full">
                {post.contentType}
              </span>
              <p className="text-white text-sm leading-relaxed">
                {post.tweet}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-green-100 rounded-xl">
              <Calendar className="h-6 w-6 text-green-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Content Strategy</h2>
          </div>
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-700 mb-3">Posting Frequency</h3>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <Instagram className="h-4 w-4 text-pink-500" />
                  <span className="text-gray-900">{socialMedia.contentStrategy.postingFrequency.instagram}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Facebook className="h-4 w-4 text-blue-600" />
                  <span className="text-gray-900">{socialMedia.contentStrategy.postingFrequency.facebook}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Twitter className="h-4 w-4 text-sky-500" />
                  <span className="text-gray-900">{socialMedia.contentStrategy.postingFrequency.twitter}</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-3">Content Mix</h3>
              <div className="space-y-2">
                {Object.entries(socialMedia.contentStrategy.contentMix).map(([key, value]) => (
                  <div key={key} className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 capitalize">{key}</span>
                    <span className="font-semibold text-gray-900">{value}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-3">Best Times to Post</h3>
              <div className="space-y-2 text-sm text-gray-600">
                <p><span className="font-medium text-gray-900">Instagram:</span> {socialMedia.contentStrategy.bestTimesToPost.instagram}</p>
                <p><span className="font-medium text-gray-900">Facebook:</span> {socialMedia.contentStrategy.bestTimesToPost.facebook}</p>
                <p><span className="font-medium text-gray-900">Twitter:</span> {socialMedia.contentStrategy.bestTimesToPost.twitter}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-3 bg-blue-100 rounded-xl">
              <Hash className="h-6 w-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-bold text-gray-900">Hashtag Strategy</h2>
          </div>
          <div className="space-y-5">
            <div>
              <h3 className="font-semibold text-gray-700 mb-3">Branded</h3>
              <div className="flex flex-wrap gap-2">
                {socialMedia.hashtagSuggestions.branded.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-gradient-to-r from-blue-500 to-blue-600 text-white text-sm rounded-full font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-3">Industry</h3>
              <div className="flex flex-wrap gap-2">
                {socialMedia.hashtagSuggestions.industry.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-gray-100 text-gray-700 text-sm rounded-full font-medium hover:bg-gray-200 transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
            <div>
              <h3 className="font-semibold text-gray-700 mb-3 flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-600" />
                Trending
              </h3>
              <div className="flex flex-wrap gap-2">
                {socialMedia.hashtagSuggestions.trending.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-3 py-1 bg-green-100 text-green-700 text-sm rounded-full font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
