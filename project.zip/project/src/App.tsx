import { useState } from 'react';
import { Sparkles, BarChart3, Share2, Palette } from 'lucide-react';
import URLInput from './components/URLInput';
import MarketingResults from './components/MarketingResults';
import SocialMediaContent from './components/SocialMediaContent';
import RedesignSuggestions from './components/RedesignSuggestions';
import type { WebsiteAnalysis } from './types/analysis';

type TabType = 'marketing' | 'social' | 'redesign';

function App() {
  const [analysis, setAnalysis] = useState<WebsiteAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<TabType>('marketing');

  const handleAnalyze = async (url: string) => {
    setIsLoading(true);
    setError('');
    setAnalysis(null);

    try {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

      const apiUrl = `${supabaseUrl}/functions/v1/analyze-website`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAnonKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to analyze website');
      }

      setAnalysis(result.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setIsLoading(false);
    }
  };

  const tabs = [
    { id: 'marketing' as TabType, label: 'Marketing Strategy', icon: BarChart3 },
    { id: 'social' as TabType, label: 'Social Media', icon: Share2 },
    { id: 'redesign' as TabType, label: 'Design & UI', icon: Palette },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl shadow-lg">
              <Sparkles className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AI Marketing Agent
            </h1>
          </div>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Analyze any website and get instant marketing insights, social media content, and redesign suggestions
          </p>
        </div>

        <URLInput onAnalyze={handleAnalyze} isLoading={isLoading} />

        {error && (
          <div className="mt-8 max-w-3xl mx-auto">
            <div className="bg-red-50 border border-red-200 rounded-xl p-4">
              <p className="text-red-800 text-center">{error}</p>
            </div>
          </div>
        )}

        {analysis && (
          <div className="mt-12 animate-fadeIn">
            <div className="bg-white rounded-2xl shadow-xl p-6 mb-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">
                    {analysis.analysis_data.title}
                  </h2>
                  <p className="text-gray-600">{analysis.url}</p>
                </div>
              </div>

              <div className="flex flex-wrap gap-3 border-b border-gray-200">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-6 py-3 font-semibold transition-all ${
                        activeTab === tab.id
                          ? 'text-blue-600 border-b-2 border-blue-600'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                      {tab.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="animate-slideUp">
              {activeTab === 'marketing' && (
                <MarketingResults marketing={analysis.marketing_suggestions} />
              )}
              {activeTab === 'social' && (
                <SocialMediaContent socialMedia={analysis.social_media_content} />
              )}
              {activeTab === 'redesign' && (
                <RedesignSuggestions redesign={analysis.redesign_suggestions} />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
