# backend/critique.py
import os, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)

def load_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(obj, name):
    p = OUTPUT / name
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    return p

def score_caption(caption, keywords):
    score = 5
    if re.search(r"\b(Tap to|Shop|Learn more|Buy|Order|Visit)\b", caption, re.I):
        score += 2
    if "#" in caption:
        score += 1
    l = len(caption)
    if 20 <= l <= 140:
        score += 1
    overlap = sum(1 for k in keywords if k.lower() in caption.lower())
    score += min(overlap, 2)
    return min(score, 10)

def improve_caption(caption, keywords):
    new = caption.strip()
    if not re.search(r"\b(Tap to|Shop|Learn more|Buy|Order|Visit)\b", new, re.I):
        new = new.rstrip('.') + ". Tap to learn more."
    if "#" not in new:
        new += " " + " ".join("#"+k.replace(" ","") for k in keywords[:2])
    if len(new) > 140:
        new = new[:137].rsplit(' ',1)[0] + "..."
    return new

def score_slogan(slogan, keywords):
    score = 5
    if len(slogan.split()) <= 6:
        score += 2
    overlap = sum(1 for k in keywords if k.lower() in slogan.lower())
    score += min(overlap,2)
    return min(score, 10)

def improve_slogan(slogan, keywords, brand_name):
    s = slogan.strip()
    parts = s.split()
    if len(parts) > 6:
        s = " ".join(parts[:6])
    if not re.search(r"\b(Discover|Create|Rise|Run|Shop|Find|Stream|Taste)\b", s, re.I):
        s = f"{brand_name} — Discover more"
    return s

def critique(copy_obj, brand_summary):
    keywords = brand_summary.get("keywords", [])
    brand_name = brand_summary.get("name","Brand")
    out = {"slogans": [], "instagram_captions": [], "linkedin_emails": []}

    for s in copy_obj.get("slogans", []):
        sc = score_slogan(s, keywords)
        improved = s if sc >= 7 else improve_slogan(s, keywords, brand_name)
        out["slogans"].append({"original": s, "score": sc, "improved": improved})

    for c in copy_obj.get("instagram_captions", []):
        sc = score_caption(c, keywords)
        improved = c if sc >= 7 else improve_caption(c, keywords)
        out["instagram_captions"].append({"original": c, "score": sc, "improved": improved})

    for e in copy_obj.get("linkedin_emails", []):
        body = e.get("body","")
        score = 5
        if 80 <= len(body) <= 400:
            score += 2
        if re.search(r"(schedule|demo|call|meet|discuss|connect)", body, re.I):
            score += 2
        improved_body = body if score >= 7 else body.strip() + "\n\nWould you have 10 minutes for a quick demo?"
        out["linkedin_emails"].append({"original": e, "score": score, "improved": {"subject": e.get("subject"), "body": improved_body}})

    return out

if __name__ == "__main__":
    cp = OUTPUT / "copy.json"
    bp = OUTPUT / "brand_summary.json"
    if not cp.exists() or not bp.exists():
        print("Expected output/copy.json and output/brand_summary.json. Run llm.py or copy dataset into output/")
        sys.exit(1)
    copy_obj = load_json(cp)
    brand_summary = load_json(bp)
    report = critique(copy_obj, brand_summary)
    save_json(report, "critique.json")
    print("Saved output/critique.json")
