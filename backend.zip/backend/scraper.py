# backend/scraper.py
import os
import sys
import json
import re
from urllib.parse import urljoin

# network HTML parsing
import requests
from bs4 import BeautifulSoup

# optional PDF parsing
try:
    from PyPDF2 import PdfReader
    _PDF_AVAILABLE = True
except Exception:
    _PDF_AVAILABLE = False

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "output")
os.makedirs(OUTPUT_DIR, exist_ok=True)

HEADERS = {
    "User-Agent": "AgenticMarketerBot/1.0 (+https://example.com) - hackathon"
}

def _safe_get_text(el):
    return el.get_text(strip=True) if el else ""

def _collect_images(soup, base_url, limit=6):
    imgs = []
    for img in soup.find_all("img"):
        src = img.get("src") or img.get("data-src") or ""
        if not src:
            continue
        src = urljoin(base_url, src)
        if src.startswith("http"):
            imgs.append(src)
        if len(imgs) >= limit:
            break
    return imgs

def _meta_content(soup, key):
    tag = soup.find("meta", attrs={"name": key})
    if tag and tag.get("content"):
        return tag.get("content")
    tag = soup.find("meta", attrs={"property": key})
    if tag and tag.get("content"):
        return tag.get("content")
    return ""

def extract_keywords(text, max_k=6):
    if not text:
        return []
    stop = set(["about","which","their","there","these","those","with","from","your","that","this","have","will","more","the","and","for","are","was","were","but"])
    words = re.findall(r"\b[a-zA-Z]{4,}\b", text.lower())
    freq = {}
    for w in words:
        if w in stop: continue
        freq[w] = freq.get(w, 0) + 1
    picks = sorted(freq.items(), key=lambda kv: (-kv[1], -len(kv[0])))
    return [p[0] for p in picks[:max_k]]

def parse_html(text, base_url):
    soup = BeautifulSoup(text, "html.parser")
    title = soup.title.string.strip() if soup.title and soup.title.string else ""
    h1 = _safe_get_text(soup.find("h1"))
    meta_description = _meta_content(soup, "description") or _meta_content(soup, "og:description") or ""
    og_title = _meta_content(soup, "og:title")
    og_description = _meta_content(soup, "og:description")
    # first substantial paragraph
    p = ""
    for para in soup.find_all("p"):
        text_p = para.get_text(strip=True)
        if len(text_p) > 30:
            p = text_p
            break
    images = _collect_images(soup, base_url, limit=6)
    page_text = " ".join([title, h1, meta_description, og_title, og_description, p]).lower()
    tone = "neutral"
    if any(k in page_text for k in ["shop", "buy now", "sale", "discount", "offer"]):
        tone = "promotional"
    elif any(k in page_text for k in ["enterprise", "solution", "platform", "api"]):
        tone = "technical"
    elif any(k in page_text for k in ["handmade", "art", "design", "boutique"]):
        tone = "artsy"
    keywords = extract_keywords(" ".join([title, meta_description, p]))
    return {
        "title": title or og_title,
        "h1": h1,
        "meta_description": meta_description,
        "og_title": og_title,
        "og_description": og_description,
        "first_paragraph": p,
        "images": images,
        "tone_hint": tone,
        "keywords": keywords
    }

def parse_pdf(path):
    if not _PDF_AVAILABLE:
        return {"text": ""}
    try:
        reader = PdfReader(path)
        texts = []
        for page in reader.pages:
            try:
                texts.append(page.extract_text() or "")
            except Exception:
                continue
        full = "\n".join(texts)
        # basic heuristics: first line as title, first long paragraph
        lines = [l.strip() for l in full.splitlines() if l.strip()]
        title = lines[0] if lines else ""
        h1 = lines[1] if len(lines) > 1 else ""
        # find first paragraph longer than 50 chars
        first_par = ""
        for l in lines:
            if len(l) > 50:
                first_par = l
                break
        keywords = extract_keywords(first_par or full)
        tone = "neutral"
        return {
            "title": title,
            "h1": h1,
            "meta_description": "",
            "og_title": "",
            "og_description": "",
            "first_paragraph": first_par,
            "images": [],
            "tone_hint": tone,
            "keywords": keywords
        }
    except Exception as e:
        return {"text": ""}

def scrape(source, timeout=10):
    # If source looks like a web URL
    if isinstance(source, str) and source.strip().lower().startswith(("http://","https://")):
        url = source.strip()
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout)
            resp.raise_for_status()
        except Exception as e:
            return {"url": url, "error": str(e)}
        data = parse_html(resp.text, url)
        data["url"] = url
        return data

    # treat source as local file path
    src_path = os.path.abspath(source)
    if not os.path.exists(src_path):
        return {"url": source, "error": "local file not found"}
    # handle PDF specially
    if src_path.lower().endswith(".pdf"):
        pdf_data = parse_pdf(src_path)
        pdf_data["url"] = src_path
        return pdf_data
    # otherwise read as html/text file
    try:
        with open(src_path, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        data = parse_html(txt, "file://" + src_path)
        data["url"] = src_path
        return data
    except Exception as e:
        return {"url": src_path, "error": str(e)}

def save_brand_json(data, filename=None):
    if not filename:
        filename = os.path.join(OUTPUT_DIR, "brand.json")
    else:
        filename = os.path.join(OUTPUT_DIR, filename)
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return filename

if __name__ == "__main__":
    import time
    if len(sys.argv) < 2:
        print("Usage: python backend/scraper.py <url_or_local_path>")
        print("Examples:")
        print("  python backend/scraper.py https://example.com")
        print("  python backend/scraper.py /mnt/data/udbhav\\ ppt\\ format.pdf")
        sys.exit(1)

    src = sys.argv[1]
    print("Scraping:", src)
    t0 = time.time()
    result = scrape(src)
    fname = save_brand_json(result)
    print("Saved:", fname)
    print("Summary:")
    print(" Title:", result.get("title"))
    print(" H1:", result.get("h1"))
    print(" Tone hint:", result.get("tone_hint"))
    print(" Images found:", len(result.get("images", [])))
    print(" Keywords:", result.get("keywords"))
    print("Elapsed: %.2fs" % (time.time() - t0))
