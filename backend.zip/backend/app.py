# backend/app.py
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
import subprocess, json, os

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output"
BACKEND = ROOT / "backend"

app = FastAPI()

class Req(BaseModel):
    brand: str = None
    url: str = None

def run_cmd(cmd):
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return proc

@app.post("/api/generate")
def generate(req: Req):
    if not req.brand and not req.url:
        raise HTTPException(400, "Provide brand or url")
    # clear output
    for f in OUTPUT.glob("*"):
        try:
            if f.is_file(): f.unlink()
        except: pass

    if req.brand:
        cmd = [ "python", str(BACKEND / "pipeline.py"), "--brand", req.brand ]
        proc = run_cmd(cmd)
        if proc.returncode != 0:
            raise HTTPException(500, f"Pipeline failed: {proc.stderr}")
    else:
        cmd = [ "python", str(BACKEND / "pipeline.py"), "--url", req.url ]
        proc = run_cmd(cmd)
        if proc.returncode != 0:
            raise HTTPException(500, f"Pipeline failed: {proc.stderr}")

    # collect outputs
    result = {}
    bs = OUTPUT / "brand_summary.json"
    cp = OUTPUT / "copy.json"
    cr = OUTPUT / "critique.json"
    if bs.exists():
        result["brand_summary"] = json.load(open(bs,"r",encoding="utf-8"))
    if cp.exists():
        result["copy"] = json.load(open(cp,"r",encoding="utf-8"))
    if cr.exists():
        result["critique"] = json.load(open(cr,"r",encoding="utf-8"))
    images = ["/api/file/"+p.name for p in OUTPUT.glob("banner_*.png")]
    result["images"] = images
    zipf = next(OUTPUT.glob("campaign_kit_*.zip"), None)
    if zipf:
        result["zip_url"] = "/api/file/" + zipf.name
    return result

from fastapi.responses import FileResponse
@app.get("/api/file/{name}")
def get_file(name: str):
    p = OUTPUT / name
    if not p.exists():
        raise HTTPException(404,"not found")
    return FileResponse(p)
