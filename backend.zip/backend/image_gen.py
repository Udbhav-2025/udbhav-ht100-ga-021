# backend/image_gen.py
import os, json, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)

def load_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def get_text_size(draw, text, font):
    """Compatible text measurement for all Pillow versions."""
    # PIL >= 10 uses textbbox
    try:
        bbox = draw.textbbox((0, 0), text, font=font)
        w = bbox[2] - bbox[0]
        h = bbox[3] - bbox[1]
        return w, h
    except Exception:
        # fallback for old versions
        return draw.textsize(text, font=font)

def create_banner(text, filename, size=(1200, 630), bg=(245, 245, 245)):
    img = Image.new('RGB', size, color=bg)
    draw = ImageDraw.Draw(img)

    # font
    try:
        font = ImageFont.truetype("arial.ttf", 48)
    except:
        font = ImageFont.load_default()

    max_width = size[0] - 150

    # wrap text manually
    words = text.split()
    lines = []
    current = ""

    for w in words:
        test = (current + " " + w).strip()
        w_w, _ = get_text_size(draw, test, font)
        if w_w <= max_width:
            current = test
        else:
            lines.append(current)
            current = w
    if current:
        lines.append(current)

    # total height
    total_h = sum(get_text_size(draw, l, font)[1] + 10 for l in lines)
    y = (size[1] - total_h) // 2

    # draw lines
    for line in lines:
        w, h = get_text_size(draw, line, font)
        x = (size[0] - w) // 2
        draw.text((x, y), line, fill=(20,20,20), font=font)
        y += h + 10

    # save file
    out = OUTPUT / filename
    img.save(out)
    return out

if __name__ == "__main__":
    copy_file = OUTPUT / "copy.json"
    if not copy_file.exists():
        print("copy.json missing. Run llm.py or pipeline first.")
        sys.exit(1)

    copy = load_json(copy_file)
    slogans = copy.get("slogans", [])[:2]
    if not slogans:
        slogans = ["Your Brand — Built to Impress"]

    for i, s in enumerate(slogans, start=1):
        fname = f"banner_{i}.png"
        p = create_banner(s, fname)
        print("Created", p)
