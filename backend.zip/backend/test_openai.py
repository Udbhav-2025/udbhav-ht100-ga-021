# test_openai.py
from dotenv import load_dotenv
import os
from openai import OpenAI
load_dotenv()
print("OPENAI key present:", bool(os.getenv("OPENAI_API_KEY")))
client = OpenAI()
resp = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[{"role":"user","content":"Say hello in one short sentence."}],
    max_tokens=20
)
print("Response:", resp.choices[0].message["content"])
