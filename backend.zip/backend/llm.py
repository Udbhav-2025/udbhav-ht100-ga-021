# backend/llm.py
"""
LLM replacement that uses local datasets only.
Usage:
  # Use a dataset by name:
  python backend/llm.py --brand apple

  # If you have run scraper and created output/brand.json:
  python backend/llm.py

  # Or pass a path (scraped JSON or local file path):
  python backend/llm.py "/path/to/scraped_or_local.json"
"""

import os
import sys
import json
import shutil
import argparse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATASETS_DIR = ROOT / "datasets"
OUTPUT_DIR = ROOT / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

SUPPORTED_BRANDS = [p.name.lower() for p in DATASETS_DIR.iterdir() if p.is_dir()]

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(obj, filename):
    p = OUTPUT_DIR / filename
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
    return p

def copy_dataset_to_output(brand):
    brand = brand.lower()
    src = DATASETS_DIR / brand
    if not src.exists():
        raise FileNotFoundError(f"Dataset for '{brand}' not found in {DATASETS_DIR}")
    shutil.copyfile(src / "brand_summary.json", OUTPUT_DIR / "brand_summary.json")
    shutil.copyfile(src / "copy.json", OUTPUT_DIR / "copy.json")
    print(f"[OK] Copied dataset '{brand}' → output/")

def try_match_brand_from_scraped(scraped):
    """
    Try to match scraped title or keywords to a dataset brand name.
    Returns matched brand name (lowercase) or None.
    """
    title = (scraped.get("title") or "").lower()
    keywords = [k.lower() for k in scraped.get("keywords", [])]
    # exact or partial title match
    for b in SUPPORTED_BRANDS:
        if b in title or title in b:
            return b
    # keyword match
    for b in SUPPORTED_BRANDS:
        # check keywords or dataset brand name tokens
        if b in keywords or any(k in b for k in keywords):
            return b
    return None

# Simple deterministic content generators (no ML)
def make_one_line(scraped):
    # Build compact one-line using title and meta
    t = scraped.get("title") or scraped.get("h1") or ""
    meta = scraped.get("meta_description") or scraped.get("first_paragraph") or ""
    if t and meta:
        one = f"{t} — {meta.split('.')[0].strip()}"
    elif t:
        one = f"{t} — quality products and services"
    else:
        one = "A trusted brand delivering great products."
    # limit length
    if len(one.split()) > 20:
        one = " ".join(one.split()[:20])
    return one

def normalize_keywords(scraped):
    kws = scraped.get("keywords") or []
    kws = [k.strip().lower() for k in kws if k and isinstance(k, str)]
    # ensure at least 3 keywords
    if len(kws) < 3:
        extra = []
        if scraped.get("title"): extra += scraped["title"].lower().split()
        if scraped.get("meta_description"): extra += scraped["meta_description"].lower().split()
        for w in extra:
            if w.isalpha() and len(w) > 3 and w not in kws:
                kws.append(w)
            if len(kws) >= 5:
                break
    return kws[:8]

def infer_tone(scraped):
    text = " ".join([scraped.get(k,"") for k in ("title","meta_description","first_paragraph")]).lower()
    if any(x in text for x in ["sale","buy now","discount","shop"]):
        return "promotional"
    if any(x in text for x in ["enterprise","solution","platform","api","business"]):
        return "technical"
    if any(x in text for x in ["handmade","art","design","boutique","style"]):
        return "artsy"
    if any(x in text for x in ["luxury","premium","exclusive"]):
        return "luxury"
    return scraped.get("tone_hint") or "neutral"

def generate_brand_summary_from_scraped(scraped):
    name = scraped.get("title") or scraped.get("h1") or "Brand"
    one_line = make_one_line(scraped)
    tone = infer_tone(scraped)
    audience = "general consumers"
    if tone == "technical":
        audience = "tech professionals and early adopters"
    elif tone == "promotional":
        audience = "bargain and mainstream shoppers"
    keywords = normalize_keywords(scraped)
    return {
        "name": name.strip(),
        "one_line": one_line,
        "tone": tone,
        "audience": audience,
        "keywords": keywords
    }

# deterministic copy generator templates
def generate_slogans(brand_summary, n=5):
    base = brand_summary.get("name","Brand")
    kws = brand_summary.get("keywords",[])
    slogans = []
    # rule-based slogans using keywords
    if kws:
        for k in kws[:3]:
            slogans.append(f"{k.capitalize()} that Inspires")
    # add variations
    slogans += [
        f"{base} — Designed for You",
        f"{base}: Quality & Innovation",
        f"Experience {base}"
    ]
    # dedupe and limit
    out = []
    for s in slogans:
        s = s.strip()
        if s not in out:
            out.append(s)
        if len(out) >= n:
            break
    # pad if needed with generic lines
    while len(out) < n:
        out.append(f"{base} — Built to Impress")
    return out[:n]

def generate_instagram_captions(brand_summary, n=3):
    base = brand_summary.get("name","Brand")
    kws = brand_summary.get("keywords",[])
    hashtags = " ".join("#" + k.replace(" ", "") for k in (kws[:3] or ["product","shop","new"]))
    captions = []
    captions.append(f"Discover {base} — {brand_summary.get('one_line')}. Tap to learn more. {hashtags}")
    captions.append(f"Bring {base} into your life. Shop now and experience the difference. {hashtags}")
    captions.append(f"{brand_summary.get('one_line')} — make it yours today. {hashtags}")
    return captions[:n]

def generate_linkedin_emails(brand_summary, n=3):
    base = brand_summary.get("name","Brand")
    emails = []
    for i in range(n):
        subj = f"Quick intro — {base} solutions"
        body = (f"Hi [Name],\n\n{brand_summary.get('one_line')} We believe this can help improve outcomes for your team or customers. "
                "Would you be open to a short 10-minute call to explore collaboration?\n\nBest,\n[Your Name]")
        emails.append({"subject": subj, "body": body})
    return emails

def generate_copy_from_brand_summary(brand_summary):
    return {
        "slogans": generate_slogans(brand_summary, n=5),
        "instagram_captions": generate_instagram_captions(brand_summary, n=3),
        "linkedin_emails": generate_linkedin_emails(brand_summary, n=3)
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default=None, help="Optional path to scraped JSON or local file (or omit to use output/brand.json).")
    parser.add_argument("--brand", "-b", help="Use a local dataset brand (e.g., apple, nike). If provided, copies dataset to output.")
    args = parser.parse_args()

    # If user explicitly asked for a brand, copy dataset and exit
    if args.brand:
        brand = args.brand.lower()
        if brand not in SUPPORTED_BRANDS:
            print(f"[ERROR] Brand '{brand}' not found in datasets. Available: {SUPPORTED_BRANDS}")
            sys.exit(1)
        copy_dataset_to_output(brand)
        return

    # Try to load scraped data
    scraped = None
    if args.path:
        path = Path(args.path)
        # If path points to dataset folder, use that dataset
        if path.is_dir() and (path / "brand_summary.json").exists():
            # copy dataset inside this folder
            # derive brand name from folder
            brand = path.name.lower()
            if brand in SUPPORTED_BRANDS:
                copy_dataset_to_output(brand)
                return
        # if a JSON file, try to load it
        if path.is_file():
            try:
                scraped = load_json(str(path))
            except Exception as e:
                print(f"[WARN] Cannot load provided file as JSON: {e}")
    else:
        # default: use output/brand.json if exists (scraper output)
        candidate = OUTPUT_DIR / "brand.json"
        if candidate.exists():
            scraped = load_json(str(candidate))

    # if we have scraped data, try to match dataset
    if scraped:
        matched = try_match_brand_from_scraped(scraped)
        if matched:
            print(f"[INFO] Matched scraped content to dataset brand: {matched}")
            copy_dataset_to_output(matched)
            return
        else:
            print("[INFO] No dataset match found — generating brand summary & copy from scraped content.")
            brand_summary = generate_brand_summary_from_scraped(scraped)
            save_json(brand_summary, "brand_summary.json")
            copy = generate_copy_from_brand_summary(brand_summary)
            save_json(copy, "copy.json")
            print("[OK] Generated brand_summary.json and copy.json in output/")
            return

    # If we reach here, no scraped file and no brand argument — fallback: list available datasets
    print("[INFO] No scraped input found and --brand not provided.")
    print("Available local datasets:", SUPPORTED_BRANDS)
    print("To use a dataset, run: python backend/llm.py --brand apple")
    sys.exit(0)

if __name__ == "__main__":
    main()
