# backend/pipeline.py
import os, shutil, sys, subprocess, time
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATASETS = ROOT / "datasets"
OUTPUT = ROOT / "output"
BACKEND = ROOT / "backend"

OUTPUT.mkdir(exist_ok=True)

def copy_dataset(brand):
    src = DATASETS / brand
    if not src.exists():
        raise FileNotFoundError(f"Dataset {brand} not found.")
    for fname in ["brand_summary.json", "copy.json"]:
        shutil.copyfile(src / fname, OUTPUT / fname)
    print(f"[OK] Copied dataset '{brand}' → output/")

def run(cmd):
    print("RUN:", " ".join(cmd))
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if proc.returncode != 0:
        print("ERROR:", proc.stderr)
        raise SystemExit(proc.stderr)
    print(proc.stdout)
    return proc

def create_zip(zipname):
    print(f"[ZIP] Creating {zipname} ...")
    with zipfile.ZipFile(zipname, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for f in OUTPUT.iterdir():
            if f.is_file():
                z.write(f, arcname=f.name)
    print("[ZIP] Done.")

def pipeline_with_brand(brand):
    copy_dataset(brand)
    run([sys.executable, str(BACKEND / "critique.py")])
    run([sys.executable, str(BACKEND / "image_gen.py")])
    ts = int(time.time())
    zipname = OUTPUT / f"campaign_kit_{brand}_{ts}.zip"
    create_zip(zipname)

def pipeline_with_url(url):
    run([sys.executable, str(BACKEND / "scraper.py"), url])
    run([sys.executable, str(BACKEND / "llm.py"), url])
    run([sys.executable, str(BACKEND / "critique.py")])
    run([sys.executable, str(BACKEND / "image_gen.py")])
    ts = int(time.time())
    zipname = OUTPUT / f"campaign_kit_url_{ts}.zip"
    create_zip(zipname)

if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--brand", help="dataset name")
    p.add_argument("--url", help="URL or file path")
    args = p.parse_args()

    if args.brand:
        pipeline_with_brand(args.brand.lower())
    elif args.url:
        pipeline_with_url(args.url)
    else:
        print("Use --brand <name> or --url <path>")
